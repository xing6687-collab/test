# 자동 정적 검사

`scripts/static_audit.py`는 최신 소스 텍스트를 읽어 반복 실수 가능성이 큰 부분을 확인한다.

## 실행 방법
```bash
python scripts/static_audit.py source/CURRENT_SOURCE.txt --out audit_report.md
```

## 현재 검사 항목
- `</html>` 뒤에 코드가 남아 있는지
- `suicide` 드론 잔재가 남아 있는지
- 작전 메타 재랜덤 선택 의심 코드가 있는지
- PC 추천 UI 관련 키워드가 있는지
- 장갑 팔레트 관련 키워드가 있는지
- 탱크 포격 경고/텔레그래프 관련 키워드가 있는지

## 주의
정적 검사는 실제 플레이를 대체하지 않는다.
다만 이름만 바뀌고 실제 분기/variant/렌더링이 남는 문제를 빨리 찾는 데 유용하다.
