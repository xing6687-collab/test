# DELIVERY TO DIE 개발 인수인계 패키지

이 패키지는 긴 대화로 인해 작업 속도가 느려지고, 일부 패치가 이름/설명만 바뀌고 실제 동작은 남는 문제를 줄이기 위한 **개발 운영 문서 세트**입니다.

## 사용 순서
1. 새 채팅 또는 다른 AI에게 `docs/00_START_PROMPT_FOR_NEW_AI.md`를 먼저 읽게 한다.
2. `source/CURRENT_SOURCE.txt`를 최신 원본으로 사용한다.
3. 작업 전 `docs/02_IMPACT_SCOPE_CHECKLIST.md`로 영향 범위를 정리한다.
4. 구현 후 `scripts/static_audit.py`와 `docs/03_QA_CHECKLIST.md`를 기준으로 검증한다.
5. 결과는 `docs/05_PATCH_NOTE_TEMPLATE.md` 형식으로 남긴다.

## 현재 포함 파일
- `source/CURRENT_SOURCE.txt` : 현재 최신 게임 소스 텍스트
- `docs/00_START_PROMPT_FOR_NEW_AI.md` : 새 AI/새 채팅 시작 프롬프트
- `docs/01_PROJECT_RULES.md` : 프로젝트 작업 규칙
- `docs/02_IMPACT_SCOPE_CHECKLIST.md` : 수정 전 영향 범위 체크리스트
- `docs/03_QA_CHECKLIST.md` : 기능별 QA 체크리스트
- `docs/04_AUTOMATED_STATIC_TESTS.md` : 정적 검사 설명
- `docs/05_PATCH_NOTE_TEMPLATE.md` : 패치노트 템플릿
- `docs/06_KNOWN_RISK_AREAS.md` : 반복 실수/충돌 위험 구역
- `docs/07_CURRENT_DESIGN_SNAPSHOT.md` : 현재 설계 스냅샷
- `scripts/static_audit.py` : 소스 정적 검사 스크립트
- `audit_report_current.md` : 현재 소스 기준 정적 검사 결과

## 기본 원칙
- HTML 미리보기/자동 실행은 하지 않는다.
- 사용자에게는 `.txt` 링크만 전달한다.
- 말로 합의한 기능은 반드시 코드 검색으로 관련 잔재를 확인한다.
- 구현 완료 보고에는 “수정/검증/주의”를 반드시 포함한다.
