# Static Audit Report for CURRENT_SOURCE.txt

## Checks

- **PASS** `NO_CODE_AFTER_HTML`
  - tail chars after </html>: 0
- **FAIL** `NO_SUICIDE_DRONE_VARIANT_REMAINS`
  -   if(t.family==="drone") return {kind:(difficulty>=5 && Math.random()<0.35?"suicide":"dronegun"), label:"드론"};
        if(false && ev.kind==="suicide"){
    else if(e.type.family==="drone"){ ctx.fillStyle="#9fd0ff"; ctx.fillRect(-r*0.95,-3,r*1.9,6); ctx.fillRect(-3,-r*0.95,6,r*1.9); ctx.fillStyle="#dfe8ff"; ctx.beginPath(); ctx.arc(0,0,r*0.45,0,7); ctx.fill(); if(false && ev.kind==="suicide"){ const blink=0.45+0.55*Math.sin(performance.now()/70); ctx.fillStyle=blink>0.55?"#ff3333":"#ffe14d"; ctx.fillText("🧨",0,-r*1.35); ctx.strokeStyle="#ff3333"; ctx.lineWidth=2; ctx.beginPath(); ctx.arc(0,0,r*(0.9+0.15*blink),0,7); ctx.stroke(); } }
    const arm=r*1.05, rr=Math.max(5,r*0.32), blink=(e.ev&&e.ev.kind==="suicide")?(0.55+0.45*Math.sin(performance.now()/55)):0;
    drawRotor(-arm,-arm,rr,e.ev&&e.ev.kind==="suicide"?"#ffb0a0":"#bdf7ff"); drawRotor(arm,-arm,rr,e.ev&&e.ev.kind==="suicide"?"#ffb0a0":"#bdf7ff"); drawRotor(-arm,arm,rr,e.ev&&e.ev.kind==="suicide"?"#ffb0a0":"#bdf7ff"); drawRotor(arm,arm,rr,e.ev&&e.ev.kind==="suicide"?"#ffb0a0":"#bdf7ff");
    ctx.fillStyle=e.ev&&e.ev.kind==="suicide"?(blink>0.52?"#ff3030":"#ffd45d"):"#4fd6ff"; roundRect(-r*0.5,-r*0.38,r,r*0.76,4); ctx.fill();
    if(e.ev&&e.ev.kind==="suicide"){ ctx.font=`${Math.max(13,r*0.9)}px sans-serif`; ctx.textAlign="center"; ctx.textBaseline="middle"; ctx.fillText("🧨",0,0); ctx.strokeStyle="#ff3333"; ctx.lineWidth=2; ctx.beginPath(); ctx.arc(0,0,r*(1.15+blink*0.25),0,7); ctx.stroke(); }
    const face=mechBodyFace(e), arm=r*1.05, rr=Math.max(5,r*0.32), blink=(e.ev&&e.ev.kind==='suicide')?(0.55+0.45*Math.sin(performance.now()/55)):0;
- **FAIL** `NO_OBVIOUS_META_RERANDOM_IN_RESET`
  - 1078: const m=operationMeta||chooseOperationMeta(), t=m.threat||{};
1346: if(!operationMeta || operationMeta.minLv>difficulty) operationMeta=chooseOperationMeta();
1350: b.addEventListener("pointerup",ev=>{ ev.preventDefault(); applyDifficulty(L); operationMeta=chooseOperationMeta(); renderDiffSel(); });
4200: const m=operationMeta||chooseOperationMeta(), t=m.threat||{};
4497: const m=operationMeta||chooseOperationMeta(), t=m.threat||{}, faction=metaFactionName(m);
- **PASS** `CONTAINS_ARMOR_THEME`
  - present
- **FAIL** `CONTAINS_pierceArmor`
  - missing
- **PASS** `CONTAINS_관통`
  - present
- **PASS** `CONTAINS_minimap`
  - present
- **PASS** `CONTAINS_AI 배송추천`
  - present
- **PASS** `TANK_TELEGRAPH_KEYWORDS_PRESENT`
  - telegraph, 포격 경고, tankShellTelegraph, 착탄

## Keyword Counts

- `infected`: 46
- `breacher`: 16
- `charger`: 28
- `spawnling`: 6
- `assault`: 64
- `suppressor`: 49
- `armored`: 61
- `droneEnemy`: 61
- `walker`: 53
- `special`: 44
