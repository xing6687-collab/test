#!/usr/bin/env python3
import argparse
import re
from pathlib import Path

CHECKS = []

def check(name, ok, detail=""):
    CHECKS.append((name, ok, detail))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('source')
    ap.add_argument('--out', default=None)
    args = ap.parse_args()
    p = Path(args.source)
    text = p.read_text(encoding='utf-8', errors='replace')

    lower = text.lower()

    # 1. code after html
    m = re.search(r'</html\s*>', text, flags=re.I)
    if m:
        tail = text[m.end():].strip()
        check('NO_CODE_AFTER_HTML', len(tail) == 0, f'tail chars after </html>: {len(tail)}')
    else:
        check('HAS_HTML_END_TAG', False, 'no </html> tag found')

    # 2. suicide drone remnants. Laser overcharge can include Korean 자폭, so focus on variant keyword.
    suicide_hits = [ln for ln in text.splitlines() if 'suicide' in ln]
    check('NO_SUICIDE_DRONE_VARIANT_REMAINS', len(suicide_hits) == 0,
          '\n'.join(suicide_hits[:8]) if suicide_hits else 'ok')

    # 3. meta reset suspected keywords
    suspicious_meta = []
    for i, ln in enumerate(text.splitlines(), 1):
        if 'resetGame' in ln or 'operationMeta' in ln or 'currentOperationMeta' in ln:
            if 'random' in ln.lower() or 'pick' in ln.lower() or 'choose' in ln.lower():
                suspicious_meta.append(f'{i}: {ln.strip()}')
    check('NO_OBVIOUS_META_RERANDOM_IN_RESET', len(suspicious_meta) == 0,
          '\n'.join(suspicious_meta[:8]) if suspicious_meta else 'ok')

    # 4. expected concepts present
    for key in ['ARMOR_THEME', 'pierceArmor', '관통', 'minimap', 'AI 배송추천']:
        check(f'CONTAINS_{key}', key in text, 'present' if key in text else 'missing')

    # 5. tank telegraph expected
    telegraph_terms = ['telegraph', '포격 경고', 'tankShellTelegraph', '착탄']
    check('TANK_TELEGRAPH_KEYWORDS_PRESENT', any(t in text for t in telegraph_terms),
          ', '.join([t for t in telegraph_terms if t in text]) or 'missing')

    # 6. summarize counts
    enemy_kind_counts = {}
    for kind in ['infected','breacher','charger','spawnling','assault','suppressor','armored','droneEnemy','walker','special']:
        enemy_kind_counts[kind] = text.count(kind)

    out_lines = []
    out_lines.append(f'# Static Audit Report for {p.name}\n')
    out_lines.append('## Checks\n')
    for name, ok, detail in CHECKS:
        mark = 'PASS' if ok else 'FAIL'
        out_lines.append(f'- **{mark}** `{name}`')
        if detail:
            out_lines.append(f'  - {detail}')
    out_lines.append('\n## Keyword Counts\n')
    for k, v in enemy_kind_counts.items():
        out_lines.append(f'- `{k}`: {v}')
    out = '\n'.join(out_lines) + '\n'
    if args.out:
        Path(args.out).write_text(out, encoding='utf-8')
    print(out)

if __name__ == '__main__':
    main()
